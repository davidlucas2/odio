const gpessoa = (prefix) => {

return `*GERADORE DE DADOS PESSOAIS:*

*THOMAS SHELBY* HEHEHEHE


}
exports.gpessoa = gpessoa
